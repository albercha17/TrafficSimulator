package simulator.view;

import javax.swing.JPanel;

import simulator.model.TrafficSimObserver;

public class ControlPanel extends JPanel implements TrafficSimObserver{

}
